# This file contains the credentials for the servers


servername = 'msIA'
root_url = 'https://msia.escriptorium.fr'
# Add your token below, e.g. {'Authorization' : 'Token  4edb72b6bdb883087b729836e498b320596a2e31'}
headers = {'Authorization' : 'Token  4edb72b6bdb883087b729836e498b320596a2e31'}
headersbrief = headers.copy()
